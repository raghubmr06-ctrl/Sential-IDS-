package com.sential.ids;

import java.time.LocalDateTime;

public record Alert(
    Long id,
    LocalDateTime timestamp,
    String sourceIp,
    String destinationIp,
    String protocol,
    String alertType,
    String severity,
    int riskScore,
    String details
) {}
