package com.sential.ids;

import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/alerts")
@CrossOrigin(origins = "*") // Restrict this to your dashboard origin before deployment.
public class AlertController {
    private final JdbcTemplate jdbc;
    public AlertController(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    @GetMapping
    public List<Map<String, Object>> list() {
        return jdbc.queryForList(
            "SELECT id, timestamp, source_ip, destination_ip, protocol, alert_type, severity, risk_score, details " +
            "FROM alerts ORDER BY timestamp DESC LIMIT 200");
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Map<String, Object> create(@RequestBody Map<String, Object> body) {
        String sourceIp = required(body, "source_ip");
        String alertType = required(body, "alert_type");
        String destinationIp = String.valueOf(body.getOrDefault("destination_ip", ""));
        String protocol = String.valueOf(body.getOrDefault("protocol", "UNKNOWN"));
        String severity = String.valueOf(body.getOrDefault("severity", "MEDIUM"));
        String details = String.valueOf(body.getOrDefault("details", ""));
        int score;
        try { score = Integer.parseInt(String.valueOf(body.getOrDefault("risk_score", "50"))); }
        catch (NumberFormatException ex) { throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "risk_score must be an integer"); }
        if (score < 0 || score > 100) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "risk_score must be 0-100");

        jdbc.update("INSERT INTO alerts (source_ip, destination_ip, protocol, alert_type, severity, risk_score, details) VALUES (?, ?, ?, ?, ?, ?, ?)",
            sourceIp, destinationIp, protocol, alertType, severity, score, details);
        return Map.of("status", "created", "alert_type", alertType, "source_ip", sourceIp);
    }

    private String required(Map<String, Object> body, String key) {
        Object value = body.get(key);
        if (value == null || value.toString().isBlank())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, key + " is required");
        return value.toString();
    }
}
