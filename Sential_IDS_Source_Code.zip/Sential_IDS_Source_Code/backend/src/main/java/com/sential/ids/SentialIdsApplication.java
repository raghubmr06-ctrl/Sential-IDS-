package com.sential.ids;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SentialIdsApplication {
    public static void main(String[] args) {
        SpringApplication.run(SentialIdsApplication.class, args);
    }
}
