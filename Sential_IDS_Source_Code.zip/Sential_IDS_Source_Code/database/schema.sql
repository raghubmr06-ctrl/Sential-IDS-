CREATE DATABASE IF NOT EXISTS sential_ids;
USE sential_ids;

CREATE TABLE IF NOT EXISTS alerts (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    timestamp TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    source_ip VARCHAR(45) NOT NULL,
    destination_ip VARCHAR(45),
    protocol VARCHAR(16),
    alert_type VARCHAR(80) NOT NULL,
    severity VARCHAR(16) NOT NULL DEFAULT 'MEDIUM',
    risk_score INT NOT NULL DEFAULT 0,
    details VARCHAR(1000)
);

CREATE INDEX idx_alerts_timestamp ON alerts(timestamp);
CREATE INDEX idx_alerts_source_ip ON alerts(source_ip);
