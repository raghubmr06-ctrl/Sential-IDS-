const API = "http://localhost:8080/api/alerts";
const el = id => document.getElementById(id);
async function loadAlerts() {
  el("status").textContent = "Loading alerts…";
  try {
    const response = await fetch(API);
    if (!response.ok) throw new Error(`API returned ${response.status}`);
    const alerts = await response.json();
    el("total").textContent = alerts.length;
    el("high").textContent = alerts.filter(a => ["HIGH","CRITICAL"].includes(String(a.severity).toUpperCase())).length;
    el("sources").textContent = new Set(alerts.map(a => a.source_ip).filter(Boolean)).size;
    el("rows").innerHTML = alerts.map(a => {
      const sev = String(a.severity || "MEDIUM").toLowerCase();
      return `<tr><td>${safe(a.timestamp)}</td><td>${safe(a.source_ip)}</td><td>${safe(a.destination_ip)}</td><td>${safe(a.protocol)}</td><td>${safe(a.alert_type)}</td><td class="severity-${safe(sev)}">${safe(a.severity)}</td><td>${safe(a.risk_score)}</td></tr>`;
    }).join("");
    el("status").textContent = `Loaded ${alerts.length} alert(s).`;
  } catch (error) {
    el("status").textContent = `Could not load alerts: ${error.message}. Start the Spring Boot API and configure MySQL.`;
  }
}
function safe(value) {
  return String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}
el("refresh").addEventListener("click", loadAlerts);
loadAlerts();
