# Sential IDS architecture

1. **Packet sensor:** C++/libpcap observes packet metadata on an authorized interface.
2. **Detection layer:** Signature rules and anomaly scoring can flag suspicious behavior. This starter includes only a demonstration ICMP observation rule; it does not implement robust scan/flood/ARP-spoof detection.
3. **REST API:** Spring Boot accepts alert JSON at `POST /api/alerts` and serves recent events at `GET /api/alerts`.
4. **Storage:** MySQL stores timestamp, IPs, protocol, alert type, severity, risk score, and details.
5. **Dashboard:** Static HTML/JS dashboard displays stored alerts and basic counts.

## Example alert JSON
```json
{
  "source_ip": "192.0.2.10",
  "destination_ip": "192.0.2.20",
  "protocol": "TCP",
  "alert_type": "PORT_SCAN_SUSPECTED",
  "severity": "HIGH",
  "risk_score": 80,
  "details": "Demonstration alert only"
}
```

Send this to `POST http://localhost:8080/api/alerts` using a local test tool after starting the backend. Use documentation-only example IP addresses unless you are monitoring an authorized environment.
