# Sential IDS — Source Code Starter Package

Sential IDS is a starter implementation of a network intrusion detection and analytics dashboard using:
- C++ / libpcap packet capture
- Java Spring Boot REST API
- MySQL event storage
- HTML/CSS/JavaScript dashboard
- Rule-based signature checks and a simple anomaly-score placeholder

IMPORTANT:
This is a generated starter project based on the Sential IDS features discussed with ChatGPT. It is not a recovery of any previously existing private repository, and it has not been security-audited or tested in your environment.

## Project structure
- `sensor-cpp/` — packet capture sensor example using libpcap
- `backend/` — Spring Boot REST API and MySQL configuration
- `database/` — database schema
- `dashboard/` — simple web dashboard
- `docs/` — architecture notes

## Quick start
1. Create a MySQL database and run `database/schema.sql`.
2. Configure database credentials in `backend/src/main/resources/application.properties`.
3. From `backend/`, run `mvn spring-boot:run` (requires Java 17+ and Maven).
4. Open `dashboard/index.html` in a browser. The dashboard calls the backend at `http://localhost:8080/api/alerts`.
5. Build the C++ sensor on a Linux machine with libpcap development headers installed. Packet capture typically requires elevated privileges. Only monitor networks you own or are authorized to assess.

## Important limitations
- The C++ example is a basic demonstration sensor, not a production IDS.
- The included alert scoring is a demonstrative heuristic, not a trained Random Forest model.
- Prevention/blocking is not implemented. Alerts do not automatically block IPs.
- Add authentication, TLS, input validation, retention controls, tests, and deployment hardening before real use.
