#include <pcap.h>
#include <arpa/inet.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <netinet/udp.h>
#include <iostream>
#include <string>
#include <cstdlib>

static void packet_handler(u_char *, const struct pcap_pkthdr *header,
                           const u_char *packet) {
    // This minimal example assumes Ethernet + IPv4. It skips other link/network types.
    if (header->caplen < 14 + sizeof(iphdr)) return;
    const auto *ip = reinterpret_cast<const iphdr *>(packet + 14);
    if (ip->version != 4) return;

    char src[INET_ADDRSTRLEN]{}, dst[INET_ADDRSTRLEN]{};
    inet_ntop(AF_INET, &ip->saddr, src, sizeof(src));
    inet_ntop(AF_INET, &ip->daddr, dst, sizeof(dst));

    std::string protocol = "OTHER";
    if (ip->protocol == IPPROTO_TCP) protocol = "TCP";
    else if (ip->protocol == IPPROTO_UDP) protocol = "UDP";
    else if (ip->protocol == IPPROTO_ICMP) protocol = "ICMP";

    std::cout << "{\"event\":\"packet_observed\",\"source_ip\":\"" << src
              << "\",\"destination_ip\":\"" << dst
              << "\",\"protocol\":\"" << protocol
              << "\",\"captured_bytes\":" << header->caplen << "}" << std::endl;

    // Demonstration signature: ICMP packets are logged as observations only.
    // A real detection rule needs flow aggregation, thresholds, and validation.
    if (ip->protocol == IPPROTO_ICMP) {
        std::cerr << "{\"event\":\"rule_observation\",\"alert_type\":\"ICMP_TRAFFIC\","
                  << "\"source_ip\":\"" << src << "\",\"destination_ip\":\""
                  << dst << "\",\"severity\":\"LOW\",\"risk_score\":20}" << std::endl;
    }
}

int main(int argc, char **argv) {
    if (argc != 2) {
        std::cerr << "Usage: sudo ./sential_sensor <interface> (example: eth0)" << std::endl;
        return 1;
    }
    char errbuf[PCAP_ERRBUF_SIZE]{};
    pcap_t *handle = pcap_open_live(argv[1], BUFSIZ, 1, 1000, errbuf);
    if (!handle) {
        std::cerr << "pcap_open_live failed: " << errbuf << std::endl;
        return 1;
    }
    std::cout << "Sential IDS sensor started on " << argv[1] << std::endl;
    const int result = pcap_loop(handle, 0, packet_handler, nullptr);
    if (result == -1) std::cerr << "Capture error: " << pcap_geterr(handle) << std::endl;
    pcap_close(handle);
    return result == -1 ? 1 : 0;
}
